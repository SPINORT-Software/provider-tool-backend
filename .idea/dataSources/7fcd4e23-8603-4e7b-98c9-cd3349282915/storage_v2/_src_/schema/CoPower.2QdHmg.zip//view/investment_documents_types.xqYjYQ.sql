create definer = admin@`%` view investment_documents_types as
select 1 AS `certificate_num`, 1 AS `investor_id`, 1 AS `SUB`, 1 AS `PAD`, 1 AS `ALTERNATIVE`;

