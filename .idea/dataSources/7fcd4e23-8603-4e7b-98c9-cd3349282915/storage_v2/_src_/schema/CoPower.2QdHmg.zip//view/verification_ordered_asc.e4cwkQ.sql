create definer = admin@`%` view verification_ordered_asc as
select 1 AS `id`,
       1 AS `user_id`,
       1 AS `transaction_id`,
       1 AS `record_id`,
       1 AS `transaction_date`,
       1 AS `name`,
       1 AS `dob`,
       1 AS `address`,
       1 AS `watch_list`,
       1 AS `three_years`;

