create definer = admin@`%` view filtered_investors as
select `i`.`id`               AS `id`,
       `i`.`uid`              AS `uid`,
       `i`.`first_name`       AS `first_name`,
       `i`.`last_name`        AS `last_name`,
       `i`.`unitholder_name`  AS `unitholder_name`,
       `i`.`type`             AS `type`,
       `i`.`accreditedStatus` AS `accreditedStatus`,
       `i`.`isRegistrant`     AS `isRegistrant`,
       `u`.`uEmail`           AS `uEmail`,
       `u`.`uDateAdded`       AS `uDateAdded`
from (`copower`.`investors` `i`
         left join `concrete5`.`users` `u` on ((`u`.`uID` = `i`.`uid`)))
where ((`i`.`uid` > 45) and (`i`.`id` not in (15, 41, 42, 47, 48, 57, 158, 160)) and
       (not ((`i`.`first_name` like '%test%'))) and (not ((`i`.`last_name` like '%test%'))) and
       (not ((`i`.`first_name` like '%sample%'))) and (not ((`u`.`uEmail` like '%test%'))));

-- comment on column filtered_investors.accreditedStatus not supported: Accredited Investor status (a,b,c,d...)

-- comment on column filtered_investors.isRegistrant not supported: Identifies investor registered with National Instrument 31-103 Registration Requirements (for Fund III).

