create definer = admin@`%` view issue_documents_types as
select `isD`.`issue_num`                                               AS `issue_num`,
       `iDoc`.`investor_id`                                            AS `investor_id`,
       (case when (`d`.`type` = 'SUB') then `d`.`doc_key` end)         AS `SUB`,
       (case when (`d`.`type` = 'PAD') then `d`.`doc_key` end)         AS `PAD`,
       (case when (`d`.`type` = 'ALTERNATIVE') then `d`.`doc_key` end) AS `ALTERNATIVE`
from (((`copower`.`documents` `d` join `copower`.`investor_documents` `iDoc` on ((`iDoc`.`document_id` = `d`.`id`))) join `copower`.`investors` on ((`copower`.`investors`.`id` = `iDoc`.`investor_id`)))
         left join `copower`.`issue_documents` `isD` on ((`d`.`id` = `isD`.`document_id`)));

