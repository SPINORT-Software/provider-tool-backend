create definer = admin@`%` view client_dealing_rep_base as
select 1 AS `uEmail`, 1 AS `dealing_rep`, 1 AS `questionnaire_id`, 1 AS `investor_id`, 1 AS `applicant_id`, 1 AS `uID`;

