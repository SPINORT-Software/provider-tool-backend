create definer = admin@`%` view issue_documents_types_pivot as
select 1 AS `issue_num`, 1 AS `investor_id`, 1 AS `SUB`, 1 AS `PAD`, 1 AS `ALTERNATIVE`;

