create definer = admin@`%` view investors_filtered as
select 1 AS `id`, 1 AS `uid`, 1 AS `first_name`, 1 AS `last_name`, 1 AS `unitholder_name`, 1 AS `type`, 1 AS `uEmail`;

