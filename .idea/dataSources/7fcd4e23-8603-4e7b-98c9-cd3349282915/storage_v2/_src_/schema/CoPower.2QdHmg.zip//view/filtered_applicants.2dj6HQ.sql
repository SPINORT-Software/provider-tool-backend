create definer = admin@`%` view filtered_applicants as
select `a`.`id`             AS `id`,
       `a`.`uid`            AS `uid`,
       `a`.`first_name`     AS `first_name`,
       `a`.`last_name`      AS `last_name`,
       `a`.`company_name`   AS `company_name`,
       `a`.`investor_type`  AS `investor_type`,
       `a`.`status`         AS `status`,
       `a`.`isReviewReopen` AS `isReviewReopen`,
       `u`.`uEmail`         AS `uEmail`,
       `u`.`uDateAdded`     AS `uDateAdded`
from (`copower`.`applicants` `a`
         left join `concrete5`.`users` `u` on ((`u`.`uID` = `a`.`uid`)))
where ((`a`.`uid` > 45) and (`a`.`id` not in
                             (4, 9, 10, 11, 12, 15, 17, 21, 23, 27, 29, 30, 38, 41, 42, 97, 131, 280, 433, 435, 437,
                              438, 439, 440, 441, 442, 446, 447, 451, 452, 453, 454, 455, 456, 459, 460, 461, 477, 484,
                              485, 506, 507, 508, 519, 521, 561, 563, 564, 651, 393, 568, 247, 290, 583, 625, 647, 709,
                              728, 736, 741, 758, 759, 787, 798, 899, 932, 1046, 1097, 1227)) and
       (not ((`a`.`first_name` like '%test%'))) and (not ((`a`.`last_name` like '%test%'))) and
       (not ((`u`.`uEmail` like '%test%'))));

