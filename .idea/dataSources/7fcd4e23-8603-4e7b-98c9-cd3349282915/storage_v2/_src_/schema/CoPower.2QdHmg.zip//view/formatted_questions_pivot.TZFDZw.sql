create definer = admin@`%` view formatted_questions_pivot as
select 1 AS `questionnaire_id`,
       1 AS `Q1`,
       1 AS `Q2`,
       1 AS `Q3`,
       1 AS `Q4`,
       1 AS `Q5`,
       1 AS `Q6`,
       1 AS `Q7`,
       1 AS `Q8`,
       1 AS `Q9`,
       1 AS `Q10`,
       1 AS `Q11`,
       1 AS `Q12`,
       1 AS `Q13`,
       1 AS `Q14`,
       1 AS `Q15`;

