create function integer_pl_date(integer, date) returns date
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select $2 + $1
$$;

comment on function integer_pl_date(integer, date) is 'implementation of + operator';

alter function integer_pl_date(integer, date) owner to "providertool-admin";

